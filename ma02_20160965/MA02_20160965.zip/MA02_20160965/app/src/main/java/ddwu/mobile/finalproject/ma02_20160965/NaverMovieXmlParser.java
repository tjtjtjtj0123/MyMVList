package ddwu.mobile.finalproject.ma02_20160965;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.StringReader;
import java.util.ArrayList;

public class NaverMovieXmlParser {

    public enum TagType { NONE, TITLE, SUBTITLE, PUBDATE, DIRECTOR, ACTOR, USERRATING, IMAGE };

    // TAG 대소문자 구분하니까 주의!!
    final static String TAG_ITEM = "item";
    final static String TAG_TITLE = "title";
    final static String TAG_SUBTITLE = "subtitle";
    final static String TAG_PUBDATE = "pubDate";
    final static String TAG_DIRECTOR = "director";
    final static String TAG_ACTOR = "actor";
    final static String TAG_USERRATING = "userRating";
    final static String TAG_IMAGE = "image";

    public NaverMovieXmlParser() {
    }

    public ArrayList<NaverMovieDto> parse(String xml) {

        ArrayList<NaverMovieDto> resultList = new ArrayList();
        NaverMovieDto dto = null;

        TagType tagType = TagType.NONE;

        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = factory.newPullParser();
            parser.setInput(new StringReader(xml));

            int eventType = parser.getEventType();
            // Boilerplate Code : 특정 기능을 구현할 때 반복적으로 비슷한 형태호 나타나는 코드
            // Ex. END_DOCIMENT, START_DOCUMENT
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        break;
                    case XmlPullParser.END_DOCUMENT:
                        break;
                    case XmlPullParser.START_TAG:
                        if (parser.getName().equals(TAG_ITEM)) {
                            dto = new NaverMovieDto();
                        } else if (parser.getName().equals(TAG_TITLE)) {
                            if (dto != null) // 반드시 item을 만난 후에, title을 체크해야하기 때문에 必
                                tagType = TagType.TITLE;
                        } else if (parser.getName().equals(TAG_SUBTITLE)) {
                            if (dto != null) // 반드시 item을 만난 후에, title을 체크해야하기 때문에 必
                                tagType = TagType.SUBTITLE;
                        } else if (parser.getName().equals(TAG_PUBDATE)) {
                            if (dto != null)
                                tagType = tagType.PUBDATE;
                        } else if (parser.getName().equals(TAG_DIRECTOR)) {
                            if (dto != null) tagType = TagType.DIRECTOR;
                        } else if (parser.getName().equals(TAG_ACTOR)) {
                            if (dto != null) tagType = TagType.ACTOR;
                        } else if (parser.getName().equals(TAG_USERRATING)) {
                            if (dto != null) tagType = TagType.USERRATING;
                        } else if (parser.getName().equals(TAG_IMAGE)) {
                            if (dto != null) tagType = TagType.IMAGE;
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        if (parser.getName().equals(TAG_ITEM)) {
                            resultList.add(dto);
                            dto = null;
                        }
                        break;
                    case XmlPullParser.TEXT:
                        switch(tagType) {
                            case TITLE:
                                dto.setTitle(parser.getText());
                                break;
                            case SUBTITLE:
                                dto.setSubtitle(parser.getText());
                                break;
                            case PUBDATE:
                                dto.setPubDate(parser.getText());
                                break;
                            case DIRECTOR:
                                dto.setDirector(parser.getText());
                                break;
                            case ACTOR:
                                dto.setActor(parser.getText());
                                break;
                            case USERRATING:
                                dto.setUserRating(parser.getText());
                                break;
                            case IMAGE:
                                dto.setImageLink(parser.getText());
                                break;
                        }
                        tagType = TagType.NONE;
                        break;
                }
                eventType = parser.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return resultList;
    }
}
