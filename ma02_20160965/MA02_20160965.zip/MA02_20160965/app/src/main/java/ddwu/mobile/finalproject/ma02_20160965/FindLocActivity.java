package ddwu.mobile.finalproject.ma02_20160965;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Handler;
import android.os.ResultReceiver;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;

import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.PlaceLikelihood;
import com.google.android.libraries.places.api.net.FetchPlaceRequest;
import com.google.android.libraries.places.api.net.FetchPlaceResponse;
import com.google.android.libraries.places.api.net.FindCurrentPlaceRequest;
import com.google.android.libraries.places.api.net.FindCurrentPlaceResponse;
import com.google.android.libraries.places.api.net.PlacesClient;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import noman.googleplaces.NRPlaces;
import noman.googleplaces.PlaceType;
import noman.googleplaces.PlacesException;
import noman.googleplaces.PlacesListener;

/* 영화관 검색 */
public class FindLocActivity extends AppCompatActivity implements OnMapReadyCallback {

    final static String TAG = "MainActivity";
    final static int PERMISSION_REQ_CODE = 100;

    /*UI*/
    private EditText etKeyword;
    private GoogleMap mGoogleMap;
    private MarkerOptions markerOptions;

    private LatLngResultReceiver latLngResultReceiver;

    /*DATA*/
    private PlacesClient placesClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loc);

        etKeyword = findViewById(R.id.etKeyword);
        mapLoad();

        /* Places 초기화 및 클라이언트 생성성 */
        Places.initialize(getApplicationContext(), getString(R.string.api_key));
//        Places.initialize(getApplicationContext(), getResources().getString(R.string.api_key)); → 기본적으로 getResource에서 검색하기 때문에 생략해도 알아서 찾아줌
        placesClient = Places.createClient(this);
        latLngResultReceiver = new LatLngResultReceiver(new Handler());
    }


    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSearch:
                Log.d("들어옴", etKeyword.getText().toString());
                startLatLngService();
                break;
        }
    }

    /* B-1) 주소 → 위도/경도 변환 IntentService 실행 */
    private void startLatLngService() {
        String address = etKeyword.getText().toString();
        Intent intent = new Intent(FindLocActivity.this, FetchLatLngIntentService.class);
        intent.putExtra(Constants.RECEIVER, latLngResultReceiver);
        intent.putExtra(Constants.ADDRESS_DATA_EXTRA, address);
        startService(intent); // B-2) service를 이용해 intent 실행
    }

    /* 주소 → 위도/경도 변환 ResultReceiver */
    class LatLngResultReceiver extends ResultReceiver {
        public LatLngResultReceiver(Handler handler) {
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData) { // send 실행시 호출됨

            String lat;
            String lng;
            ArrayList<LatLng> latLngList = null;

            if (resultCode == Constants.SUCCESS_RESULT) {
                if (resultData == null) return;
                latLngList = (ArrayList<LatLng>) resultData.getSerializable(Constants.RESULT_DATA_KEY);
                if (latLngList == null) {
                    lat = (String) getResources().getString(R.string.init_lat);
                    lng = (String) getResources().getString(R.string.init_lng);
                } else {
                    LatLng latlng = latLngList.get(0);
                    lat = String.valueOf(latlng.latitude);
                    lng = String.valueOf(latlng.longitude);
                }

                LatLng latLng = new LatLng(Double.valueOf(lat), Double.valueOf(lng));
                searchStart(latLng);
            } else {
                    LatLng latLng = new LatLng(Double.valueOf(getResources().getString(R.string.init_lat)),
                            Double.valueOf(getResources().getString(R.string.init_lng)));
                    searchStart(latLng);
            }

        }
    }


    /*입력된 유형의 주변 정보를 검색 - 비동기적으로 장소 정보 요청됨*/
    private void searchStart(LatLng latLng) { // 1) 위치 정보 검색 및 검색 타입 지정
        Log.d("설치스타트!!", String.valueOf(latLng.latitude));
        mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17));
        new NRPlaces.Builder().listener(placesListener)
                .key(getResources().getString(R.string.api_key))
                .latlng(Double.valueOf(latLng.latitude),
                        Double.valueOf(latLng.longitude))
                .radius(200)
                .type(PlaceType.MOVIE_THEATER)
                .build()
                .execute();
    }


    /*Place ID 의 장소에 대한 세부정보 획득*/
    private void getPlaceDetail(final String placeId) {
        List<Place.Field> placeFields = Arrays.asList(Place.Field.ID, Place.Field.NAME,
                Place.Field.PHONE_NUMBER, Place.Field.ADDRESS);

        FetchPlaceRequest request = FetchPlaceRequest.builder(placeId, placeFields).build(); // 요청 생성 - place API 요청 객체

        /* 요청 처리 및 요청 성공/실패 리스너 지정 */
        placesClient.fetchPlace(request).addOnSuccessListener( // 성공시
                new OnSuccessListener<FetchPlaceResponse>() {
                    @Override
                    public void onSuccess(FetchPlaceResponse response) { // 3) Google에서 제공하는 Place로 장소에 대한 세부 정보 받아옴
                        Place place = response.getPlace(); // 장소 정보
                        Log.d(TAG, "place found: " + place.getName());
                        Log.d(TAG, "phone: " + place.getPhoneNumber());
                        Log.d(TAG, "Address: " + place.getAddress());
                        Intent intent = new Intent(FindLocActivity.this, LDetailActivity.class);
                        intent.putExtra("name", place.getName());
                        intent.putExtra("phone", place.getPhoneNumber());
                        intent.putExtra("address", place.getAddress());

                        startActivity(intent);
                    }
                }
        ).addOnFailureListener(new OnFailureListener() { // 실패시
                                                                           @Override
                                                                           public void onFailure(@NonNull Exception e) {
                                                                               if (e instanceof ApiException) {
                                                                                   ApiException apiException = (ApiException) e;
                                                                                   int statusCode = apiException.getStatusCode();
                                                                                   Log.e(TAG, "Place not found: " + statusCode + " " + e.getMessage());
                                                                               }
                                                                           }
                                                                       }
        );
    }


    private void callDetailActivity(Place place) {
        Intent intent = new Intent(FindLocActivity.this, LDetailActivity.class);
        intent.putExtra("name", place.getName());
        intent.putExtra("phone", place.getPhoneNumber());
        intent.putExtra("address", place.getAddress());

        startActivity(intent);
    }


    PlacesListener placesListener = new PlacesListener() {

        @Override
        public void onPlacesFailure(PlacesException e) {

        }

        @Override
        public void onPlacesStart() {

        }

        @Override
        public void onPlacesSuccess(final List<noman.googleplaces.Place> places) { // 2) noman.googleplaces.Place에서 placeId 추출
            // noman.googleplaces.Place는 풀패키지명을 사용하므로 import가 불필요
            Log.d(TAG, "Adding Markers");

            // 마커 추가
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    for (noman.googleplaces.Place place : places) {
                        markerOptions.title(place.getName());
                        markerOptions.position(new LatLng(place.getLatitude(), place.getLongitude()));
                        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(
                                BitmapDescriptorFactory.HUE_RED
                        ));
                        Marker newMarker = mGoogleMap.addMarker(markerOptions);
                        newMarker.setTag(place.getPlaceId()); // 장소 정보 저장 - placeId
                        Log.d(TAG, place.getName() + " : " + place.getPlaceId());
                    }
                }
            });

        }

        @Override
        public void onPlacesFinished() {

        }
    };


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;
        markerOptions = new MarkerOptions(); // 마커 옵션 준비
        Log.d(TAG, "Map ready");

        if (checkPermission()) {
            mGoogleMap.setMyLocationEnabled(true); // 내 위치 표시 마커 활성화
        }

        /*내 위치 확인 버튼 클릭 처리 리스너*/
        mGoogleMap.setOnMyLocationButtonClickListener(new GoogleMap.OnMyLocationButtonClickListener() {
            @Override
            public boolean onMyLocationButtonClick() {
                Toast.makeText(FindLocActivity.this, "Clicked!", Toast.LENGTH_SHORT).show();
                return false;
            }
        });

        /* 지도 상의 현재 위치 아이콘 클릭 처리 리스너*/
        mGoogleMap.setOnMyLocationClickListener(new GoogleMap.OnMyLocationClickListener() {
            @Override
            public void onMyLocationClick(@NonNull Location location) {
                Toast.makeText(FindLocActivity.this,
                        String.format("현재위치: (%f, %f)", location.getLatitude(), location.getLongitude()),
                        Toast.LENGTH_SHORT).show();
            }
        });

        /* 검색한 장소의 상세 정보 요청 처리*/
        mGoogleMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                String placeId = marker.getTag().toString();
                getPlaceDetail(placeId); // 해당 placeId에 대한 장소 세부정보 찾기
            }
        });
    }


    /*구글맵을 멤버변수로 로딩*/
    private void mapLoad() {
        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);      // 매배변수 this: MainActivity 가 OnMapReadyCallback 을 구현하므로
        // Async 수행시, 자동으로 onMapReady가 수행됨
    }


    /* 필요 permission 요청 */
    private boolean checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        PERMISSION_REQ_CODE);
                return false;
            }
        }
        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PERMISSION_REQ_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // 퍼미션을 획득하였을 경우 맵 로딩 실행
                mapLoad();
            } else {
                // 퍼미션 미획득 시 액티비티 종료
                Toast.makeText(this, "앱 실행을 위해 권한 허용이 필요함", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }



//
//    /*구글이 현재 위치의 주변 정보를 확인하는 기본 방법 사용 메소드*/
//    private void startCPSearch() {
//        // Use fields to define the data types to return.
//        List<Place.Field> placeFields = Collections.singletonList(Place.Field.ID);
//
//        // Use the builder to create a FindCurrentPlaceRequest.
//        FindCurrentPlaceRequest request = FindCurrentPlaceRequest.newInstance(placeFields);
//
//        // Call findCurrentPlace and handle the response (first check that the user has granted permission).
//
//        if (checkPermission()) {
//            Task<FindCurrentPlaceResponse> placeResponse = placesClient.findCurrentPlace(request);
//            placeResponse.addOnCompleteListener(new OnCompleteListener<FindCurrentPlaceResponse>() {
//                @Override
//                public void onComplete(@NonNull Task<FindCurrentPlaceResponse> task) {
//                    if (task.isSuccessful()){
//                        FindCurrentPlaceResponse response = task.getResult();
//                        for (PlaceLikelihood placeLikelihood : response.getPlaceLikelihoods()) {
////                            Log.i(TAG, String.format("Place ID: %s", placeLikelihood.getPlace().getId()));
//                            Log.i(TAG, String.format("Place '%s' has likelihood: %f",
//                                    placeLikelihood.getPlace().getId(),
//                                    placeLikelihood.getLikelihood()));
//                        }
//                    } else {
//                        Exception exception = task.getException();
//                        if (exception instanceof ApiException) {
//                            ApiException apiException = (ApiException) exception;
//                            Log.e(TAG, "Place not found: " + apiException.getStatusCode());
//                        }
//                    }
//                }
//            });
//        }
//    }

}
