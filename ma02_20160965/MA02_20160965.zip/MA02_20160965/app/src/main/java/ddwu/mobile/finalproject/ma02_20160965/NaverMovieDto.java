package ddwu.mobile.finalproject.ma02_20160965;

import android.text.Html;
import android.text.Spanned;

import java.io.Serializable;

public class NaverMovieDto implements Serializable {

    private int _id;
    private String title;
    private String subtitle;
    private String pubDate;
    private String director;
    private String actor;
    private String userRating;
    private String link;
    private String imageLink;
    private String imageFileName;

    public String getSubtitle() {
        Spanned spanned = Html.fromHtml(subtitle);
        return spanned.toString();
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getTitle() {
        Spanned spanned = Html.fromHtml(title);
        return spanned.toString();
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPubDate() {
        return pubDate;
    }

    public void setPubDate(String pubDate) {
        this.pubDate = pubDate;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getUserRating() {
        return userRating;
    }

    public void setUserRating(String userRating) {
        this.userRating = userRating;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }

    public String getImageFileName() {
        return imageFileName;
    }

    public void setImageFileName(String imageFileName) {
        this.imageFileName = imageFileName;
    }
}
