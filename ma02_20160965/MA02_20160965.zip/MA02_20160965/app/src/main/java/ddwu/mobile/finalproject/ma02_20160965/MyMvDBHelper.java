package ddwu.mobile.finalproject.ma02_20160965;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyMvDBHelper extends SQLiteOpenHelper {

    private final static String DB_NAME = "mvmv_db";
    public final static String TABLE_NAME = "mymv_table";
    public final static String COL_IMG = "img";
    public final static String COL_ID = "_id";
    public final static String COL_NAME = "name";
    public final static String COL_SUBTITLE = "subtitle";
    public final static String COL_PUBDATE = "pubdate";
    public final static String COL_DIRECTOR = "director";
    public final static String COL_ACTOR = "actor";
    public final static String COL_USERRATING = "userrating";
    public final static String COL_MYSCORE = "myscore";
    public final static String COL_MYREPORT = "myreport";
    public final static String COL_MYWATCHINGDATE = "mywatchingdate";

    public MyMvDBHelper(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + " ( " + COL_ID + " integer primary key autoincrement," + COL_NAME + " TEXT, " + COL_IMG + " TEXT, " + COL_SUBTITLE + " TEXT, " + COL_PUBDATE + " TEXT, " + COL_DIRECTOR + " TEXT, " + COL_ACTOR + " TEXT, " + COL_USERRATING + " TEXT, " + COL_MYSCORE  + " TEXT, " + COL_MYREPORT  + " TEXT, " + COL_MYWATCHINGDATE + " TEXT);");

//		샘플 데이터
//        db.execSQL("INSERT INTO " + TABLE_NAME + " VALUES (null, '조제', null, 'joje', '20200101', '연주성', '8.75', '8.0', '한지민, 남주혁, 허진', '좋은데,,,그닥', '20200101');");
//        db.execSQL("INSERT INTO " + TABLE_NAME + " VALUES (null, '김치나물', null, 'kimchi', '20201010', 'caplin', '1.5', '8.9', 'yeonju seong', 'good!!', '20201111');");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table " + TABLE_NAME);
        onCreate(db);
    }
}
