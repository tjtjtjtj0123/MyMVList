package ddwu.mobile.finalproject.ma02_20160965;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v) {
        Intent intent = null;

        switch (v.getId()) {
            case R.id.btn_showall: // 내 인생 영화 리스트
                intent = new Intent(this, AllMyActivity.class);
                break;
            case R.id.btn_search: // 새로운 영화 검색
                intent = new Intent(this, SearchActivity.class);
                break;
            case R.id.btn_searchloc: // 영화관 검색
                intent = new Intent(this, FindLocActivity.class);
                break;
        }

        if (intent != null) {
            Log.d("TAG", "intent 있음");
            startActivity(intent);
        }
    }
}