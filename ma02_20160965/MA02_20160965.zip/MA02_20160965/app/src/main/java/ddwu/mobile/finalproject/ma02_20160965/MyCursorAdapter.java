package ddwu.mobile.finalproject.ma02_20160965;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyCursorAdapter extends CursorAdapter {

    LayoutInflater inflater;
    int layout;
    private NaverNetworkManager networkManager = null;
    private ImageFileManager imageFileManager = null;
    ViewHolder holder;

    public MyCursorAdapter(Context context, int layout, Cursor c) {
        super(context, c, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.layout = layout;
        imageFileManager = new ImageFileManager(context);
        networkManager = new NaverNetworkManager(context);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        View view = inflater.inflate(layout, parent, false);
        ViewHolder holder = new ViewHolder();
        view.setTag(holder);

        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        holder = (ViewHolder) view.getTag();

        if (holder.tvName == null){
            holder.tvName = view.findViewById(R.id.tvName);
            holder.tvUserRating = view.findViewById(R.id.tvUserRating);
            holder.ivImage = view.findViewById(R.id.ivImage);
        }

        holder.tvName.setText(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_NAME)));
        holder.tvUserRating.setText(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_USERRATING)));

        if (cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_IMG)) == null) { // 간혹 image 없이 정보가 가져와지는 경우가 있음
            holder.ivImage.setImageResource(R.mipmap.ic_launcher);
        }
        else {
            // 파일에 있는지 확인
            // dto 의 이미지 주소 정보로 이미지 파일 읽기
            Log.d("MyCursor출력!!!!!!!!!!!", cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_IMG)));
            Bitmap savedBitmap = imageFileManager.getBitmapFromTemporary(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_IMG))); //파일 이름 - 5) URL 이용해, 저장된 Image bitmap 가져오기

            if (savedBitmap != null) {
                holder.ivImage.setImageBitmap(savedBitmap); // viewHolder에 있는 정보 가져옴
                Log.d("TAG", "Image loading from file");
            } else { // 방법2 사용시, 이부분 필요 x
                holder.ivImage.setImageResource(R.mipmap.ic_launcher); // 파일이 없는 경우, 기본 이미지로 설정
                new GetImageAsyncTask().execute(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_IMG))); // 이미지를 가져와 반환함 = 화면이 보이기 시작함. but, 네트워크가 느린 경우 기본 아이콘이 보일 수 있음
                Log.d("TAG", "Image loading from network");
            }
        }
    }

    static class ViewHolder {
        public ViewHolder(){
            tvUserRating = null;
            tvName = null;
            ivImage = null;
        }

        TextView tvName;
        TextView tvUserRating;
        ImageView ivImage;
    }
    class GetImageAsyncTask extends AsyncTask<String, Void, Bitmap> { //6) 이미지 다운로드에 Bitmap에 setting

        String imageAddress;

        @Override
        protected Bitmap doInBackground(String... params) {
            imageAddress = params[0];
            Bitmap result = null;
            result = networkManager.downloadImage(imageAddress);
            return result;
        }


        @Override
        protected void onPostExecute(Bitmap bitmap) {
            /*작성할 부분*/
            /*네트워크에서 다운 받은 이미지 파일을 ImageFileManager 를 사용하여 내부저장소에 저장
             * 다운받은 bitmap 을 이미지뷰에 지정*/
            if (bitmap != null){
                holder.ivImage.setImageBitmap(bitmap);
                imageFileManager.saveBitmapToTemporary(bitmap, imageAddress);
            }
        }



    }


}
