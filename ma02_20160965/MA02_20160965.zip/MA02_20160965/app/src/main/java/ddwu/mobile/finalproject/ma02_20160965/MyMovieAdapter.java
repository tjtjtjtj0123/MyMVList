package ddwu.mobile.finalproject.ma02_20160965;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyMovieAdapter extends BaseAdapter {

    public static final String TAG = "MyMovieAdapter";

    private LayoutInflater inflater;
    private Context context;
    private int layout;
    private ArrayList<NaverMovieDto> list;
    private NaverNetworkManager networkManager = null;
    private ImageFileManager imageFileManager = null;


    public MyMovieAdapter(Context context, int resource, ArrayList<NaverMovieDto> list) {
        this.context = context;
        this.layout = resource; // 각 리스트 한 줄에 해당하는 layout
        this.list = list;
        imageFileManager = new ImageFileManager(context);
        networkManager = new NaverNetworkManager(context);
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public int getCount() {
        return list.size();
    }


    @Override
    public NaverMovieDto getItem(int position) {
        return list.get(position);
    }


    @Override
    public long getItemId(int position) {
        return list.get(position).get_id();
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Log.d(TAG, "getView with position : " + position);
        View view = convertView;
        ViewHolder viewHolder = null;

        if (view == null) {
            view = inflater.inflate(layout, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.tvName = view.findViewById(R.id.tvName);
            viewHolder.tvScore = view.findViewById(R.id.tvScore);
            viewHolder.ivImage = view.findViewById(R.id.ivImage);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder)view.getTag();
        }

        NaverMovieDto dto = list.get(position);

        viewHolder.tvName.setText(dto.getTitle());
        viewHolder.tvScore.setText(dto.getUserRating());

        /*작성할 부분*/
//         dto의 이미지 주소에 해당하는 이미지 파일이 내부저장소에 있는지 확인
//         ImageFileManager 의 내부저장소에서 이미지 파일 읽어오기 사용
//         이미지 파일이 있을 경우 bitmap, 없을 경우 null 을 반환하므로 bitmap 이 있으면 이미지뷰에 지정
//         없을 경우 GetImageAsyncTask 를 사용하여 이미지 파일 다운로드 수행
        if (dto.getImageLink() == null) { // 간혹 image 없이 정보가 가져와지는 경우가 있음
            viewHolder.ivImage.setImageResource(R.mipmap.ic_launcher);
            return view;
        }

        // 파일에 있는지 확인
        // dto 의 이미지 주소 정보로 이미지 파일 읽기
        Bitmap savedBitmap = imageFileManager.getBitmapFromTemporary(dto.getImageLink()); //파일 이름 - 5) URL 이용해, 저장된 Image bitmap 가져오기

        if (savedBitmap != null){
            viewHolder.ivImage.setImageBitmap(savedBitmap); // viewHolder에 있는 정보 가져옴
            Log.d(TAG, "Image loading from file");
        } else { // 방법2 사용시, 이부분 필요 x
            viewHolder.ivImage.setImageResource(R.mipmap.ic_launcher); // 파일이 없는 경우, 기본 이미지로 설정
            new GetImageAsyncTask(viewHolder).execute(dto.getImageLink()); // 이미지를 가져와 반환함 = 화면이 보이기 시작함. but, 네트워크가 느린 경우 기본 아이콘이 보일 수 있음
            Log.d(TAG, "Image loading from network");
        }

        return view;
    }


    public void setList(ArrayList<NaverMovieDto> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    //    ※ findViewById() 호출 감소를 위해 필수로 사용할 것
    static class ViewHolder {
        public TextView tvName = null;
        public TextView tvScore = null;
        public ImageView ivImage = null;
    }


    /* 책 이미지를 다운로드 후 내부저장소에 파일로 저장하고 이미지뷰에 표시하는 AsyncTask */
    // 1. 네트워크에서 이미지 다운
    // 2. 뷰홀더에 이미지 설정
    // 3. 이미지 파일 저장
    class GetImageAsyncTask extends AsyncTask<String, Void, Bitmap> { //6) 이미지 다운로드에 Bitmap에 setting

        ViewHolder viewHolder;
        String imageAddress;

        // 현재의 viewHolder 확인
        public GetImageAsyncTask(ViewHolder holder) {
            viewHolder = holder;
        }

        @Override
        protected Bitmap doInBackground(String... params) {
            imageAddress = params[0];
            Bitmap result = null;
            result = networkManager.downloadImage(imageAddress);
            return result;
        }


        @Override
        protected void onPostExecute(Bitmap bitmap) {
            /*작성할 부분*/
            /*네트워크에서 다운 받은 이미지 파일을 ImageFileManager 를 사용하여 내부저장소에 저장
             * 다운받은 bitmap 을 이미지뷰에 지정*/
            if (bitmap != null){
                viewHolder.ivImage.setImageBitmap(bitmap);
                imageFileManager.saveBitmapToTemporary(bitmap, imageAddress);
            }
        }



    }

}

