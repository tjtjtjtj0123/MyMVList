package ddwu.mobile.finalproject.ma02_20160965;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

/* 검색된 영화 상세보기*/
public class SDetailActivity extends AppCompatActivity implements Serializable{
    TextView tvName;
    TextView tvPubDate;
    TextView tvDirector;
    TextView tvActor;
    TextView tvUserRating;
    ImageView ivImage;
    NaverMovieDto dto;
    MyMvDBHelper helper;
    NaverNetworkManager networkManager = null;
    ImageFileManager imageFileManager = null;
    int _index;

    ArrayList<NaverMovieDto> mvList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sdetail);

            tvName = findViewById(R.id.tvName);
            tvPubDate = findViewById(R.id.tvPubDate);
            tvDirector = findViewById(R.id.tvDirector);
            tvActor = findViewById(R.id.tvActor);
            tvUserRating = findViewById(R.id.tvUserRating);
            ivImage = findViewById(R.id.ivImage);

        Intent intent = getIntent();
        _index = intent.getIntExtra("index", 0);
        mvList = (ArrayList<NaverMovieDto>) intent.getSerializableExtra("list");
        dto = mvList.get(_index);
        imageFileManager = new ImageFileManager(SDetailActivity.this);
        networkManager = new NaverNetworkManager(SDetailActivity.this);

        tvName.setText(dto.getTitle() + "(" + dto.getSubtitle() + ")");
        tvPubDate.setText(dto.getPubDate());
        tvDirector.setText(dto.getDirector());
        tvActor.setText(dto.getActor());
        tvUserRating.setText(dto.getUserRating());
        Log.d("출력!!!!!!!!!!!", dto.getImageLink());
        if (dto.getImageLink() == null) { // 간혹 image 없이 정보가 가져와지는 경우가 있음
            ivImage.setImageResource(R.mipmap.ic_launcher);
        }else {

            // 파일에 있는지 확인
            // dto 의 이미지 주소 정보로 이미지 파일 읽기
            Log.d("출력!!!!!!!!!!!", dto.getImageLink());
            Bitmap savedBitmap = imageFileManager.getBitmapFromTemporary(dto.getImageLink()); //파일 이름 - 5) URL 이용해, 저장된 Image bitmap 가져오기

            if (savedBitmap != null) {
                ivImage.setImageBitmap(savedBitmap); // viewHolder에 있는 정보 가져옴
                Log.d("TAG", "Image loading from file");
            } else { // 방법2 사용시, 이부분 필요 x
                ivImage.setImageResource(R.mipmap.ic_launcher); // 파일이 없는 경우, 기본 이미지로 설정
                new GetImageAsyncTask().execute(dto.getImageLink()); // 이미지를 가져와 반환함 = 화면이 보이기 시작함. but, 네트워크가 느린 경우 기본 아이콘이 보일 수 있음
                Log.d("TAG", "Image loading from network");
            }
        }
    }

    class GetImageAsyncTask extends AsyncTask<String, Void, Bitmap> { //6) 이미지 다운로드에 Bitmap에 setting

        String imageAddress;

        @Override
        protected Bitmap doInBackground(String... params) {
            imageAddress = params[0];
            Bitmap result = null;
            result = networkManager.downloadImage(imageAddress);
            return result;
        }


        @Override
        protected void onPostExecute(Bitmap bitmap) {
            /*작성할 부분*/
            /*네트워크에서 다운 받은 이미지 파일을 ImageFileManager 를 사용하여 내부저장소에 저장
             * 다운받은 bitmap 을 이미지뷰에 지정*/
            if (bitmap != null){
                ivImage.setImageBitmap(bitmap);
                imageFileManager.saveBitmapToTemporary(bitmap, imageAddress);
            }
        }



    }

    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btnAddMv:
//                DB 데이터 업데이트 작업 수행
                helper = new MyMvDBHelper(this);
                SQLiteDatabase db = helper.getWritableDatabase();
                ContentValues row = new ContentValues();
                row.put(MyMvDBHelper.COL_IMG, dto.getImageLink());
                row.put(MyMvDBHelper.COL_NAME, tvName.getText().toString());
                row.put(MyMvDBHelper.COL_ACTOR, tvActor.getText().toString());
                row.put(MyMvDBHelper.COL_DIRECTOR, tvDirector.getText().toString());
                row.put(MyMvDBHelper.COL_PUBDATE, tvPubDate.getText().toString());
                row.put(MyMvDBHelper.COL_USERRATING, tvUserRating.getText().toString());
                db.insert(MyMvDBHelper.TABLE_NAME, null, row);
                helper.close();
                finish();
                break;
            case R.id.btnUpdateShopClose:
//                DB 데이터 업데이트 작업 취소
                finish();
                break;
        }
    }


}
