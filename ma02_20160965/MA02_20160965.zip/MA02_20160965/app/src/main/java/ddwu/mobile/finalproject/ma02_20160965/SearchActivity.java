package ddwu.mobile.finalproject.ma02_20160965;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

/* 새로운 영화 검색 */
public class SearchActivity extends AppCompatActivity {
    public static final String TAG = "SearchActivity";
    private  int REQUEST_TEST = 1;

    EditText etTarget;
    ListView lvList;
    String apiAddress;

    String query;

    MyMovieAdapter adapter;
    ArrayList<NaverMovieDto> resultList;
    NaverMovieXmlParser parser;
    NaverNetworkManager networkManager;
    ImageFileManager imgFileManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        etTarget = findViewById(R.id.etTarget);
        lvList = findViewById(R.id.lvList);

        resultList = new ArrayList();
        adapter = new MyMovieAdapter(this, R.layout.listview_search, resultList);

        lvList.setAdapter(adapter);

        apiAddress = getResources().getString(R.string.api_url);
        parser = new NaverMovieXmlParser();
        networkManager = new NaverNetworkManager(this);
        //naver 검색 기능을 사용하는 경우 setting 필요
        networkManager.setClientId(getResources().getString(R.string.client_id));
        networkManager.setClientSecret(getResources().getString(R.string.client_secret));
        imgFileManager = new ImageFileManager(this);

        lvList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id) {
//                수정 기능 작성 - UpdateActivity 를 결과를 받아오는 형태로 호출
                if (REQUEST_TEST != RESULT_OK) {
                    Intent intent = new Intent(SearchActivity.this, SDetailActivity.class);
                    intent.putExtra("index", pos);
                    intent.putExtra("list", resultList);
                    startActivityForResult(intent, REQUEST_TEST);
                }
            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 임시 파일 삭제
        imgFileManager.clearTemporaryFiles();
    }


    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btnSearch:
                query = etTarget.getText().toString();  // UTF-8 인코딩 필요
                // OpenAPI 주소와 query 조합 후 서버에서 데이터를 가져옴
                // 가져온 데이터는 파싱 수행 후 어댑터에 설정
                try { // 1) query (URL) 전송
                    new NetworkAsyncTask().execute(apiAddress
                            + URLEncoder.encode(query, "UTF-8"));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                break;
        }
    }

    /*전송받은 url 쿼리에 맞춰 Async 동작*/
    class NetworkAsyncTask extends AsyncTask<String, Integer, String> {
        ProgressDialog progressDlg;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDlg = ProgressDialog.show(SearchActivity.this, "Wait", "Downloading...");
        }

        @Override
        protected String doInBackground(String... strings) { //2) NaverBookXmlParser에서 query 검색 결과 리스트 받아옴
//      protected ArrayList<NaverMovieDto> doInBackground(String... strings) { // 방법2
            String address = strings[0];
            String result = null;
            // networking : 주소로 해당 컨텐츠 string으로 받아옴
            result = networkManager.downloadContents(address);
            if (result == null) return "Error!";

            Log.d(TAG, result);

            // parsing
            resultList = parser.parse(result); // 방법2

//            for (NaverMovieDto dto : resultList) { // 방법2
//                Bitmap bitmap = networkManager.downloadImage(dto.getImageLink());
//                if (bitmap != null) imgFileManager.saveBitmapToTemporary(bitmap,
//                        dto.getImageLink());
//            }

            return result;
        }


        @Override
        protected void onPostExecute(String result) { // 여기서 부터는 main 스레드 - 3) Async 결과 XML 적용함
            //parsing
//            resultList = parser.parse(result); // 방법1
            adapter.setList(resultList);    // Adapter 에 결과 List 를 설정 후 notify - 4) XML 결과 Adapter 이용해 적용
            progressDlg.dismiss(); //dialog 사라짐
        }

    }

}
