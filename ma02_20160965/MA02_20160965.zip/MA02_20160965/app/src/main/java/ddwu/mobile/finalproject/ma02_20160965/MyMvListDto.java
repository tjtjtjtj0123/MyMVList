package ddwu.mobile.finalproject.ma02_20160965;

import android.text.Html;
import android.text.Spanned;

import java.io.Serializable;

public class MyMvListDto implements Serializable {

    private long id;
    private String title;
    private String subtitle;
    private String pubDate;
    private String director;
    private String actor;
    private String userRating;
    private String link;
    private String imageLink;
    private String imageFileName;
    private String myscore;
    private String myreport;
    private String mywatchingdate;

    public MyMvListDto() {

    }

    public MyMvListDto(long id, String title, String subtitle, String pubDate, String director, String actor, String userRating, String link, String imageLink, String imageFileName, String myscore, String myreport, String mywatchingdate) {
        this.id = id;
        this.title = title;
        this.subtitle = subtitle;
        this.pubDate = pubDate;
        this.director = director;
        this.actor = actor;
        this.userRating = userRating;
        this.link = link;
        this.imageLink = imageLink;
        this.imageFileName = imageFileName;
        this.myscore = myscore;
        this.myreport = myreport;
        this.mywatchingdate = mywatchingdate;
    }

    public String getTitle() {
        Spanned spanned = Html.fromHtml(title);
        return spanned.toString();
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubtitle() {
        Spanned spanned = Html.fromHtml(subtitle);
        return spanned.toString();
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public String getPubDate() {
        return pubDate;
    }

    public void setPubDate(String pubDate) {
        this.pubDate = pubDate;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getUserRating() {
        return userRating;
    }

    public void setUserRating(String userRating) {
        this.userRating = userRating;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }

    public String getImageFileName() {
        return imageFileName;
    }

    public void setImageFileName(String imageFileName) {
        this.imageFileName = imageFileName;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getMyscore() {
        return myscore;
    }

    public void setMyscore(String myscore) {
        this.myscore = myscore;
    }

    public String getMyreport() {
        return myreport;
    }

    public void setMyreport(String myreport) {
        this.myreport = myreport;
    }

    public String getMywatchingdate() {
        return mywatchingdate;
    }

    public void setMywatchingdate(String mywatchingdate) {
        this.mywatchingdate = mywatchingdate;
    }
}
