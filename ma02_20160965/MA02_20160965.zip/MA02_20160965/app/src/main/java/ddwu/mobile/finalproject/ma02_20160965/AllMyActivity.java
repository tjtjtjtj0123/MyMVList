package ddwu.mobile.finalproject.ma02_20160965;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

/* 내 인생 영화 리스트 - 전체 보기 */
public class AllMyActivity extends AppCompatActivity {
    ListView lvShopList = null;
    MyMvDBHelper helper;
    MyMvListDto shopDto;
    Cursor cursor;
    MyCursorAdapter adapter;
    private  int REQUEST_TEST = 1;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showall);
        lvShopList = (ListView)findViewById(R.id.lvList);
        helper = new MyMvDBHelper(this);

        adapter = new MyCursorAdapter(this, R.layout.listview_mymv, null);

        lvShopList.setAdapter(adapter);

//		리스트 뷰 클릭 처리 - 영화 상세 정보 보기
        lvShopList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id) {
//                수정 기능 작성 - UpdateActivity 를 결과를 받아오는 형태로 호출
                if (REQUEST_TEST != RESULT_OK) {
                    Intent intent = new Intent(AllMyActivity.this, MDetailActivity.class);
                    intent.putExtra("index", id);
                    startActivityForResult(intent, REQUEST_TEST);
                }
            }
        });

//		리스트 뷰 롱클릭 처리 - 영화 정보 리스트에서 삭제
        lvShopList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                // 삭제 경우, "delete from contact_table where _id =" + id
                // query로 position 사용 없이 id로 검색,삭제
                final long pos = id;
                AlertDialog.Builder builder = new AlertDialog.Builder(AllMyActivity.this);
                builder.setMessage("삭제하시겠습니까?");
                builder.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
//                        DB 삭제 수행
                        SQLiteDatabase db = helper.getWritableDatabase();
                        db.execSQL("DELETE FROM " + MyMvDBHelper.TABLE_NAME +" where _id = " + pos);
//                        새로운 DB 내용으로 리스트뷰 갱신
                        readAllShoplist();
                        adapter.notifyDataSetChanged();
                    }
                });
                builder.setNegativeButton("취소", null);
                builder.show();
                return true;
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();
//        DB에서 데이터를 읽어와 Adapter에 설정
        SQLiteDatabase db = helper.getReadableDatabase();
        cursor = db.rawQuery("select * from " + MyMvDBHelper.TABLE_NAME, null);

        adapter.changeCursor(cursor);
        helper.close();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        cursor 사용 종료
        if (cursor != null) cursor.close();
    }

    private void readAllShoplist() {
        cursor.close();

        SQLiteDatabase db = helper.getReadableDatabase();
        cursor = db.rawQuery("select * from " + MyMvDBHelper.TABLE_NAME, null);

        adapter.changeCursor(cursor);
        helper.close();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_TEST)
            if (resultCode == RESULT_OK) {
                Toast.makeText(AllMyActivity.this, "Success!" , Toast.LENGTH_SHORT).show();
            }

//        } else if (requestCode == REQUEST_ANOTHER) {
//            ...
    }
}
