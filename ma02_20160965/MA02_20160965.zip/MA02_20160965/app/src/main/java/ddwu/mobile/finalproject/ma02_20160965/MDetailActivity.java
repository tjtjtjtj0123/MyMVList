package ddwu.mobile.finalproject.ma02_20160965;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/* 내 영화 상세 정보 보기 */
public class MDetailActivity extends AppCompatActivity {
    TextView tvName;
    TextView tvPubDate;
    TextView tvDirector;
    TextView tvActor;
    TextView tvUserRating;
    ImageView ivImage;
    EditText etMyScore;
    EditText etMyReport;
    EditText etMyWatchingDate;
    long _index;
    private NaverNetworkManager networkManager = null;
    private ImageFileManager imageFileManager = null;

    MyMvDBHelper helper;
    Cursor cursor;
    MyCursorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mdetail);

        tvName = findViewById(R.id.tvName);
        tvActor = findViewById(R.id.tvActor);
        tvDirector = findViewById(R.id.tvDirector);
        tvPubDate = findViewById(R.id.tvPubDate);
        tvUserRating = findViewById(R.id.tvUserRating);
        ivImage = findViewById(R.id.ivImage);
        etMyScore = findViewById(R.id.etMyScore);
        etMyReport = findViewById(R.id.etMyReport);
        etMyWatchingDate = findViewById(R.id.etMyWatchingDate);

        imageFileManager = new ImageFileManager(MDetailActivity.this);
        networkManager = new NaverNetworkManager(MDetailActivity.this);

        Intent intent = getIntent();
        helper = new MyMvDBHelper(this);
        _index = intent.getLongExtra("index", 0);
        SQLiteDatabase db = helper.getReadableDatabase();
        cursor = db.rawQuery("select * from " + MyMvDBHelper.TABLE_NAME + " where _id = " + _index, null);

        while(cursor.moveToNext()) {
            tvName.setText(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_NAME)));
            tvActor.setText(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_ACTOR)));
            tvDirector.setText(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_DIRECTOR)));
            tvPubDate.setText(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_PUBDATE)));
            tvUserRating.setText(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_USERRATING)));
            etMyScore.setText(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_MYSCORE)));
            etMyReport.setText(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_MYREPORT)));
            etMyWatchingDate.setText(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_MYWATCHINGDATE)));

            if (cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_IMG)) == null) { // 간혹 image 없이 정보가 가져와지는 경우가 있음
                ivImage.setImageResource(R.mipmap.ic_launcher);
            }else {

                // 파일에 있는지 확인
                // dto 의 이미지 주소 정보로 이미지 파일 읽기
                Log.d("출력!!!!!!!!!!!", cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_IMG)));
                Bitmap savedBitmap = imageFileManager.getBitmapFromTemporary(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_IMG))); //파일 이름 - 5) URL 이용해, 저장된 Image bitmap 가져오기

                if (savedBitmap != null) {
                    ivImage.setImageBitmap(savedBitmap); // viewHolder에 있는 정보 가져옴
                    Log.d("TAG", "Image loading from file");
                } else { // 방법2 사용시, 이부분 필요 x
                    ivImage.setImageResource(R.mipmap.ic_launcher); // 파일이 없는 경우, 기본 이미지로 설정
                    new GetImageAsyncTask().execute(cursor.getString(cursor.getColumnIndex(MyMvDBHelper.COL_IMG))); // 이미지를 가져와 반환함 = 화면이 보이기 시작함. but, 네트워크가 느린 경우 기본 아이콘이 보일 수 있음
                    Log.d("TAG", "Image loading from network");
                }
            }
        }
    }

    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btnUpdateShop:
//                DB 데이터 업데이트 작업 수행
                SQLiteDatabase db = helper.getWritableDatabase();
                ContentValues row = new ContentValues();
//                row.put(MyMvDBHelper.COL_NAME, tvName.getText().toString());
//                row.put(MyMvDBHelper.COL_ACTOR, tvActor.getText().toString());
//                row.put(MyMvDBHelper.COL_DIRECTOR, tvDirector.getText().toString());
//                row.put(MyMvDBHelper.COL_PUBDATE, tvPubDate.getText().toString());
//                row.put(MyMvDBHelper.COL_USERRATING, tvUserRating.getText().toString());
                row.put(MyMvDBHelper.COL_MYSCORE, etMyScore.getText().toString());
                row.put(MyMvDBHelper.COL_MYREPORT, etMyReport.getText().toString());
                row.put(MyMvDBHelper.COL_MYWATCHINGDATE, etMyWatchingDate.getText().toString());
                String whereClause = "_id=?";
                String[] whereArgs = new String[]{Long.toString(_index)};
                db.update(MyMvDBHelper.TABLE_NAME, row, whereClause, whereArgs);
                helper.close();
                Intent intent = new Intent();
                setResult(RESULT_OK, intent);
                finish();
                break;
            case R.id.btnUpdateShopClose:
//                DB 데이터 업데이트 작업 취소
                finish();
                break;
        }
    }

    class GetImageAsyncTask extends AsyncTask<String, Void, Bitmap> { //6) 이미지 다운로드에 Bitmap에 setting

        String imageAddress;

        @Override
        protected Bitmap doInBackground(String... params) {
            imageAddress = params[0];
            Bitmap result = null;
            result = networkManager.downloadImage(imageAddress);
            return result;
        }


        @Override
        protected void onPostExecute(Bitmap bitmap) {
            /*작성할 부분*/
            /*네트워크에서 다운 받은 이미지 파일을 ImageFileManager 를 사용하여 내부저장소에 저장
             * 다운받은 bitmap 을 이미지뷰에 지정*/
            if (bitmap != null){
                ivImage.setImageBitmap(bitmap);
                imageFileManager.saveBitmapToTemporary(bitmap, imageAddress);
            }
        }



    }
}
