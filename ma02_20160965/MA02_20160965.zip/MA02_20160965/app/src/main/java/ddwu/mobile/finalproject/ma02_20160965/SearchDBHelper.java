package ddwu.mobile.finalproject.ma02_20160965;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SearchDBHelper extends SQLiteOpenHelper {

    private final static String DB_NAME = "mvmv_db";
    public final static String TABLE_NAME = "mymv_table";
    public final static String COL_ID = "_id";
    public final static String COL_NAME = "name";
    public final static String COL_SUBTITLE = "subtitle";
    public final static String COL_PUBDATE = "pubdate";
    public final static String COL_DIRECTOR = "director";
    public final static String COL_ACTOR = "actor";
    public final static String COL_USERRATING = "userrating";

    public SearchDBHelper(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + " ( " + COL_ID + " integer primary key autoincrement," + COL_NAME + " TEXT, " + COL_SUBTITLE + " TEXT, " + COL_PUBDATE + " TEXT, " + COL_DIRECTOR + " TEXT, " + COL_ACTOR + " TEXT, " + COL_USERRATING + " TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table " + TABLE_NAME);
        onCreate(db);
    }
}
